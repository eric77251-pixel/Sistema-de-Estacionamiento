# Panel de Estacionamientos Inteligentes

Dashboard web para mostrar en tiempo real los tres espacios de estacionamiento del proyecto.

## Arquitectura

- Tres ESP32 independientes, uno por espacio: `P01`, `P02` y `P03`.
- Cada ESP32 publica su telemetría al broker HiveMQ.
- El backend Python (Paho MQTT) recibe los mensajes individuales, valida los datos y mantiene el estado consolidado.
- El backend publica un único resumen para el dashboard.
- El dashboard se conecta a HiveMQ mediante MQTT sobre WebSockets.

## Configuración MQTT del dashboard

La configuración se encuentra en `app.ts`:

```ts
brokerUrl: "wss://broker.hivemq.com:8884/mqtt",
topic: "ds8/1gs133/estacionamiento/dashboard",
totalSpaces: 3,
```

El ESP32 continúa usando MQTT TCP en el puerto `1883`. El navegador no puede conectarse directamente mediante TCP, por eso el dashboard usa WebSockets sobre el puerto `8884`. HiveMQ publica los puertos TCP y WebSocket en su información del broker.

## Mensaje que debe publicar el backend

El backend debe publicar en:

```text
ds8/1gs133/estacionamiento/dashboard
```

Con este formato consolidado:

```json
{
  "parking_lot_id": "LOT001",
  "timestamp": "2026-11-07T18:00:00Z",
  "total_spaces": 3,
  "available_spaces": 2,
  "occupied_spaces": 1,
  "spaces": [
    { "id": "P01", "available": true },
    { "id": "P02", "available": false },
    { "id": "P03", "available": true }
  ]
}
```

Reglas:
- `available: true` significa LIBRE.
- `available: false` significa OCUPADO.
- Si un espacio todavía no ha enviado datos, se mostrará gris como **Sin datos**.
- El backend debe enviar los tres espacios en cada resumen. No debe marcar como libre un espacio del que no haya recibido una medición válida.

## Tópicos individuales esperados desde los ESP32

Se recomienda configurar cada dispositivo con su propio identificador en el tópico base:

```text
ds8/1gs133/estacionamiento/P01/telemetria
ds8/1gs133/estacionamiento/P02/telemetria
ds8/1gs133/estacionamiento/P03/telemetria
```

El estado de conexión y las órdenes también deben quedar separados por dispositivo:

```text
ds8/1gs133/estacionamiento/P01/estado
ds8/1gs133/estacionamiento/P01/cmd
```

Y de igual manera para `P02` y `P03`.

El identificador puede obtenerse del tópico, por lo que no es obligatorio añadirlo al JSON que publica cada ESP32. El JSON de telemetría de cada dispositivo puede conservar estos campos:

```json
{
  "ESTADO": "LIBRE",
  "DISTANCIA_CM": 120.5,
  "DETECION_OBJETO": "FALSE"
}
```

## Instalar y ejecutar

Requisitos: Node.js 18+ y npm.

```bash
npm install
npm run build
npm run serve
```

Abrir `http://localhost:8080`.

`index.html` carga `app.js`, que es la versión JavaScript compilada de `app.ts`. Cada vez que se modifique `app.ts`, ejecutar `npm run build`.

## Nota sobre el broker público

`broker.hivemq.com` es un broker público de pruebas. Los tópicos son visibles para otros usuarios y no deben transportar información sensible. Para el proyecto académico, utilicen un prefijo único de grupo y eviten publicar datos privados.

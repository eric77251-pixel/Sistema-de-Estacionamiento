"use strict";
/* ============================================================
   Smart Parking Dashboard — Application Logic
   ------------------------------------------------------------
   Responsibilities:
     - MQTT over WebSockets connection & reconnection
     - JSON payload validation (with TypeScript types)
     - Parking state management
     - UI rendering (spaces, counters, status, timestamp)
   ============================================================ */
const CONFIG = {
    // ⚠️ PLACEHOLDER — replace with your broker's WebSocket URL.
    // Examples:
    //   Public test broker: "wss://test.mosquitto.org:8081/mqtt"
    //   Local EMQX:         "ws://localhost:8083/mqtt"
    //   Local Mosquitto:    "ws://localhost:8080/mqtt"
    brokerUrl: "wss://broker.hivemq.com:8884/mqtt",
    // ⚠️ PLACEHOLDER — topic your Python device publishes to.
    topic: "ds8/1gs133/estacionamiento/dashboard",
    // Unique per browser tab to avoid client-ID collisions.
    clientId: `smart-parking-dashboard-${Math.random().toString(16).slice(2, 10)}`,
    // ⚠️ PLACEHOLDER — leave empty if the broker is anonymous.
    username: "",
    password: "",
    totalSpaces: 3,
};
/* ------------------------------------------------------------
   3. State
   ------------------------------------------------------------ */
const state = {
    lotId: "—",
    spaces: new Map(),
    lastUpdated: null,
};
// Initialize all configured spaces as "unknown" (null).
for (let i = 1; i <= CONFIG.totalSpaces; i++) {
    state.spaces.set(`P${String(i).padStart(2, "0")}`, null);
}
/* ------------------------------------------------------------
   4. DOM references
   ------------------------------------------------------------ */
const el = {
    lot: document.getElementById("lot"),
    availableCount: document.getElementById("available-count"),
    availableSub: document.getElementById("available-sub"),
    occupiedCount: document.getElementById("occupied-count"),
    unknownCount: document.getElementById("unknown-count"),
    totalCount: document.getElementById("total-count"),
    lotId: document.getElementById("lot-id"),
    lastUpdated: document.getElementById("last-updated"),
    statusArea: document.getElementById("status-area"),
    connStatus: document.getElementById("conn-status"),
    connText: document.getElementById("conn-text"),
};
/* ------------------------------------------------------------
   5. UI rendering
   ------------------------------------------------------------ */
/** Build the 3-space grid once. */
function renderLotSkeleton() {
    el.lot.innerHTML = "";
    for (const [id] of state.spaces) {
        const spaceEl = document.createElement("div");
        spaceEl.className = "space space--unknown";
        spaceEl.setAttribute("role", "listitem");
        spaceEl.dataset.spaceId = id;
        const icon = document.createElement("span");
        icon.className = "space-icon";
        icon.textContent = "?";
        const idEl = document.createElement("span");
        idEl.className = "space-id";
        idEl.textContent = id;
        const statusEl = document.createElement("span");
        statusEl.className = "space-status";
        statusEl.textContent = "Unknown";
        spaceEl.append(icon, idEl, statusEl);
        el.lot.appendChild(spaceEl);
    }
}
/** Apply a status (true/false/null) to one space element. */
function applySpaceStatus(spaceEl, available) {
    const icon = spaceEl.querySelector(".space-icon");
    const status = spaceEl.querySelector(".space-status");
    spaceEl.classList.remove("space--available", "space--occupied", "space--unknown");
    if (available === true) {
        spaceEl.classList.add("space--available");
        icon.textContent = "✔";
        status.textContent = "Disponible";
    }
    else if (available === false) {
        spaceEl.classList.add("space--occupied");
        icon.textContent = "✕";
        status.textContent = "Ocupado";
    }
    else {
        spaceEl.classList.add("space--unknown");
        icon.textContent = "?";
        status.textContent = "Sin datos";
    }
}
/** Render the entire state to the DOM. */
function renderState(changedIds = new Set()) {
    // Spaces
    for (const [id, available] of state.spaces) {
        const spaceEl = el.lot.querySelector(`.space[data-space-id="${id}"]`);
        if (!spaceEl)
            continue;
        const prev = spaceEl.dataset.lastStatus ?? "unset";
        const next = available === null ? "unknown" : available ? "available" : "occupied";
        spaceEl.dataset.lastStatus = next;
        applySpaceStatus(spaceEl, available);
        if (changedIds.has(id) && prev !== "unset") {
            spaceEl.classList.remove("flash");
            // Force reflow so the animation can restart.
            void spaceEl.offsetWidth;
            spaceEl.classList.add("flash");
        }
    }
    // Counters
    let available = 0;
    let occupied = 0;
    let unknown = 0;
    for (const v of state.spaces.values()) {
        if (v === true)
            available++;
        else if (v === false)
            occupied++;
        else
            unknown++;
    }
    el.availableCount.textContent = String(available);
    el.occupiedCount.textContent = String(occupied);
    el.unknownCount.textContent = String(unknown);
    el.totalCount.textContent = String(state.spaces.size);
    el.availableSub.textContent = `of ${state.spaces.size} spaces`;
    // Lot id
    el.lotId.textContent = `LOT: ${state.lotId}`;
    // Last updated timestamp
    if (state.lastUpdated) {
        el.lastUpdated.textContent = state.lastUpdated.toLocaleTimeString();
    }
}
/** Update the connection status pill. */
function setConnectionStatus(stateName) {
    el.connStatus.dataset.state = stateName;
    const labels = {
        connected: "Conectado",
        connecting: "Conectando…",
        disconnected: "Desconectado",
        error: "Error de conexión",
    };
    el.connText.textContent = labels[stateName];
}
/** Non-intrusive status message area. */
function setStatusMessage(msg, kind = "") {
    el.statusArea.textContent = msg;
    el.statusArea.className = "status-area" + (kind ? ` ${kind}` : "");
}
/* ------------------------------------------------------------
   6. Validation
   ------------------------------------------------------------ */
/**
 * Validate and normalize an incoming payload.
 * Returns a normalized map of space ID -> available | null, or null on failure.
 *
 * Rules:
 *   - Must be an object.
 *   - `spaces` must be an array of { id: string, available: boolean }.
 *   - Unknown IDs are ignored; missing IDs become `null` (unknown).
 *   - Counts are recomputed from the spaces array (source of truth).
 */
function normalizePayload(raw) {
    if (typeof raw !== "object" || raw === null)
        return null;
    const obj = raw;
    if (!Array.isArray(obj.spaces))
        return null;
    const lotId = typeof obj.parking_lot_id === "string" ? obj.parking_lot_id : "—";
    let timestamp = new Date();
    if (typeof obj.timestamp === "string") {
        const parsed = new Date(obj.timestamp);
        if (!Number.isNaN(parsed.getTime()))
            timestamp = parsed;
    }
    // Start from current state so unknown spaces are preserved.
    const nextSpaces = new Map(state.spaces);
    const changedIds = new Set();
    for (const item of obj.spaces) {
        if (typeof item !== "object" || item === null)
            continue;
        const { id, available } = item;
        if (typeof id !== "string")
            continue;
        if (typeof available !== "boolean")
            continue;
        if (!nextSpaces.has(id)) {
            // Ignore IDs not part of the configured layout.
            continue;
        }
        if (nextSpaces.get(id) !== available) {
            changedIds.add(id);
        }
        nextSpaces.set(id, available);
    }
    return { lotId, timestamp, spaces: nextSpaces, changedIds };
}
let client = null;
let hasSubscribed = false; // guard against duplicate subscriptions
let handlersBound = false; // guard against duplicate event handlers
function connectMqtt() {
    setConnectionStatus("connecting");
    setStatusMessage("Conectando con el broker…", "warn");
    const options = {
        clientId: CONFIG.clientId,
        clean: true,
        reconnectPeriod: 3000, // auto-reconnect every 3s
        connectTimeout: 10000,
        keepalive: 30,
    };
    if (CONFIG.username)
        options.username = CONFIG.username;
    if (CONFIG.password)
        options.password = CONFIG.password;
    try {
        client = mqtt.connect(CONFIG.brokerUrl, options);
    }
    catch (err) {
        setConnectionStatus("error");
        setStatusMessage(`No se pudo crear el cliente MQTT: ${err.message}`, "error");
        return;
    }
    // Bind handlers only once, even if connectMqtt is called again.
    if (handlersBound)
        return;
    handlersBound = true;
    client.on("connect", () => {
        setConnectionStatus("connected");
        setStatusMessage("Conectado. Esperando datos de los estacionamientos…", "ok");
        // Subscribe only once per connection lifecycle, and only if not already subscribed.
        if (!hasSubscribed) {
            client.subscribe(CONFIG.topic, { qos: 0 }, (err) => {
                if (err) {
                    setStatusMessage(`Error al suscribirse: ${err.message}`, "error");
                    return;
                }
                hasSubscribed = true;
            });
        }
    });
    client.on("reconnect", () => {
        setConnectionStatus("connecting");
        setStatusMessage("Reconectando con el broker…", "warn");
        // After a reconnect, re-subscribe if the broker session was lost.
        hasSubscribed = false;
    });
    client.on("close", () => {
        if (el.connStatus.dataset.state !== "connecting") {
            setConnectionStatus("disconnected");
        }
    });
    client.on("offline", () => {
        setConnectionStatus("disconnected");
        setStatusMessage("Broker desconectado. Reintentando…", "warn");
    });
    client.on("error", (err) => {
        setConnectionStatus("error");
        setStatusMessage(`Error MQTT: ${err.message}`, "error");
    });
    client.on("message", (topic, payload) => {
        if (topic !== CONFIG.topic)
            return;
        let parsed;
        try {
            const text = new TextDecoder().decode(payload);
            parsed = JSON.parse(text);
        }
        catch {
            setStatusMessage("Se recibió un JSON incorrecto; se ignoró.", "error");
            return;
        }
        const normalized = normalizePayload(parsed);
        if (!normalized) {
            setStatusMessage("Se recibió un mensaje inválido; se ignoró.", "error");
            return;
        }
        // Commit state
        state.lotId = normalized.lotId;
        state.spaces = normalized.spaces;
        state.lastUpdated = normalized.timestamp;
        renderState(normalized.changedIds);
        const changed = normalized.changedIds.size;
        setStatusMessage(`Actualización recibida${changed ? ` (${changed} cambio${changed === 1 ? "" : "s"})` : ""}.`, "ok");
    });
}
/* ------------------------------------------------------------
   8. Boot
   ------------------------------------------------------------ */
function init() {
    renderLotSkeleton();
    renderState();
    connectMqtt();
}
// Run once the DOM is ready (script is at end of body, but be safe).
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
}
else {
    init();
}
//# sourceMappingURL=app.js.map